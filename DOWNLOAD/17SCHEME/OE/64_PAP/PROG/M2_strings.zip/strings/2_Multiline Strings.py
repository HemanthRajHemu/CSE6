#You can assign a multiline string to a variable by using three quotes:
a = """Python
Future Vision BIE
Code Available"""

b = '''Python
Future Vision BIE
Code Available'''

print(a)
print(b)
