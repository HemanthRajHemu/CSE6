#Get the characters from position 2 to position 5 (not included):
b = "Hello, World!"
print(b[2:5])
