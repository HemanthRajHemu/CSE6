a = "Hello"
print(a)
