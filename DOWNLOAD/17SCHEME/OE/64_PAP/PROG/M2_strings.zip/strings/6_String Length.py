#The len() function returns the length of a string:
a = "Hello, World!"
print(len(a))
