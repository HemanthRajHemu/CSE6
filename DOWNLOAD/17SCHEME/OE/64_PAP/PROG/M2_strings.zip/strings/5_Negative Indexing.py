b = "Hello, World!"
#Get the characters from position 5 to position 1, starting the count from the end of the string:
print(b[-5:-2])
