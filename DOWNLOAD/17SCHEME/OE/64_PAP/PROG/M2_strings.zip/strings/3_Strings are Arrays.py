a = "Hello, World!"
print(a[0])

#can we have Negative Values?
print(a[-1]) #reverse Prints the String
print(a[-2])
print(a[-3])
