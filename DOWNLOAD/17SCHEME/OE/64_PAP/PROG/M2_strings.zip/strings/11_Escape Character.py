txt = "We are the so-called \"Vikings\" from the north."
txt1 = ''' Future Vision "BIE" '''
txt2 = """ Python "Code" """
txt3 = 'Python "code"'
txt4 = "Python 'code'"
print(txt)
print(txt1)
print(txt2)
print(txt3)
print(txt4)
