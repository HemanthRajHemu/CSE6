def my_function():
  print("HELLO FUTURE VISION BIE")

my_function()
