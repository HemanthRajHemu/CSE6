def my_function(fname):
  print("Welcome {}\nHope your Doing Grear\n".format(fname))

my_function("hemanth")
my_function("Future Vision BIE")
my_function("Aman")
