#Import math Library
import math

#Return the first value, with the sign of the second value
print(math.copysign(4, -1))
print(math.copysign(-8, 97.21))
print(math.copysign(-43, -76))
