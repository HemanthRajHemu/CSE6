# Import math Library
import math

#Return the value of 9 raised to the power of 3
print(math.pow(9, 3))
