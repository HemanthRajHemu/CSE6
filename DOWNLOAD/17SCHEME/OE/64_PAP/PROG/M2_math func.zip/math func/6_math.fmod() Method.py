# Import math Library
import math

# Return the remainder after modulo operation
print (math.fmod(67, 7))
print (math.fmod(17, 4))
print (math.fmod(16, 4))
