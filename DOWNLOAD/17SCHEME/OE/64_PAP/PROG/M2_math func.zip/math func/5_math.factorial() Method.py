#Import math Library
import math

#Return factorial of a number
print(math.factorial(9))
print(math.factorial(6))
print(math.factorial(12))
