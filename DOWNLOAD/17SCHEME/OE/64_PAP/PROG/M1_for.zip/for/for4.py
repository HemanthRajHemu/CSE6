for x in range(2,10,2): #range(init value,end value,increment value)
  print(x)
