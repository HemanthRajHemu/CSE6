adj = ["red", "big", "tasty"]
fruits = ["apple", "banana", "cherry"]

for x in adj: #3
  for y in fruits: #123
    print(x, y)
