i = 1
while i < 6:
  print(i)
  if i == 3:
    break     #With the break statement we can stop the loop even if the while condition is true:
  i += 1
