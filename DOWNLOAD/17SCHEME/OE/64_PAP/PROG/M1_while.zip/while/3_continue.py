i = 0
while i < 6:
  i += 1
  print(i)
  if i == 4:
    continue      #With the continue statement we can stop the current iteration, and continue with the next:
  #print(i)
