i = 1
while i < 6:
  
  i += 1
  print(i)
else:
  #print(i)
  print("i is no longer less than 6")
