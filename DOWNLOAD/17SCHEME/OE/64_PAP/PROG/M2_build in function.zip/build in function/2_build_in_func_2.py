def x():    #Check if a function is callable:
  a = 5

print(callable(x))


x = chr(97)       #Get the character that represents the unicode 97:
print(x)


x = int(3.5)
print(x)
x = float(3)
print(x)

print('Enter your name:')
x = input()             #Ask for the user's name and print it:
print('Hello, ' + x)

print("Hello World")    # print("Hello World")


x = round(5.76543, 2)   #Round a number to only two decimals:
print(x)

alph = ["a", "b", "c", "d"]
ralph = reversed(alph)  #Reverse the sequence of a list, and print each item:
for x in ralph:
  print(x)
