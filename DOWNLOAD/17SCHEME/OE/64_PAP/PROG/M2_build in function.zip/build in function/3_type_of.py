a = ('apple', 'banana', 'cherry')
b = "Hello World"
c = 33

x = type(a)       #Return the type of these objects:
y = type(b)
z = type(c)
