x = abs(-356)     #The abs() function returns the absolute value of the specified number.
print(x)

mylist = [0, 1, 1] #Check if all items in a list are True
x = all(mylist)
print(x)

mylist = [1, True, 1] #Check if all items in a list are True
y = all(mylist)
print(y)

mydict = {0 : "Apple", 1 : "Orange"}
z = all(mydict)
print(z)

mylist = [False, True, False]       #Check if any item in a set is True:
x = any(mylist)
print(x)

x = ascii("My name is Ståle")  #Escape non-ascii characters:
print(x)

x = bin(36)       #Return the binary version of 36:
print(x)

x = bool(1)       #Return the boolean value of 1:
print(x)

x = bytearray(4)  #Return an array of 4 bytes:
print(x)

x = bytes(4)      #Return an array of 4 bytes:
print(x)
