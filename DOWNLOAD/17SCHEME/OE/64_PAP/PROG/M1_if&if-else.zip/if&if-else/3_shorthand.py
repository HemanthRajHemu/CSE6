a=100
b=77
if a > b: print("a is greater than b")
