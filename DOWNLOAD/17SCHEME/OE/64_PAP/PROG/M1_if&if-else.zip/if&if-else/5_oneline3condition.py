a = 5
b = 330
print("A")
print(">") if a > b else print("=") if a == b else print("<")
#nested Shorthand
print("B")
