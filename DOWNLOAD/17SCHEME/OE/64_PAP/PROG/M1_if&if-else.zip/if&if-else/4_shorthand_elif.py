a = 772
b = 330
print("A","B")
print("A") if a > b else print("B") #shorthand 
