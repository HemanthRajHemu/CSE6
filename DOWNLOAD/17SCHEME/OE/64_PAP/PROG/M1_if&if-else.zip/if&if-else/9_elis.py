a=10
b=int(input('Enter the valid Number\na: 10\nb:'))
if b > a:
  print("b is greater than a")
elif a == b:
  print("a and b are equal")
else:
  print("a is greater than b")
